function copyServerIP(){
  const ip='harxSMP.aternos.me';
  navigator.clipboard?.writeText(ip).then(()=>{
    const buttons=document.querySelectorAll('[data-copy-ip]');
    buttons.forEach(btn=>{const old=btn.textContent;btn.textContent='Skopiowano ✓';setTimeout(()=>btn.textContent=old,1600)});
  });
}

document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  document.querySelectorAll('[data-copy-ip]').forEach(btn=>btn.addEventListener('click',copyServerIP));
});
